import sys

def check_dependencies():
    missing = []
    praw = None
    openai = None
    try:
        import praw as praw_mod
        praw = praw_mod
    except ModuleNotFoundError:
        print("Warning: The 'praw' module is not installed. Some features will be unavailable.")
        missing.append('praw')
    try:
        import openai as openai_mod
        openai = openai_mod
    except ModuleNotFoundError:
        print("Warning: The 'openai' module is not installed. Some features will be unavailable.")
        missing.append('openai')
    return len(missing) == 0, praw, openai

# Reddit API Credentials
REDDIT_CLIENT_ID = 'vJTc5mqRATOVAreOwtc1Sw'
REDDIT_CLIENT_SECRET = 'c9058GgIG0SwArdlWuj96blzX0U3pg'
REDDIT_USER_AGENT = 'user_persona_script'
OPENAI_API_KEY = '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'

def fetch_user_data(username, reddit):
    user = reddit.redditor(username)
    posts = []
    comments = []
    try:
        for post in user.submissions.new(limit=20):
            posts.append({'title': post.title, 'body': post.selftext})
        for comment in user.comments.new(limit=20):
            comments.append({'body': comment.body})
    except Exception as e:
        print(f"Error fetching data: {e}")
    return posts, comments

def build_persona(posts, comments, openai):
    content = ""
    if posts:
        content += "Posts:\n"
        for post in posts:
            content += f"Title: {post['title']}\nBody: {post['body']}\n\n"
    if comments:
        content += "Comments:\n"
        for comment in comments:
            content += f"{comment['body']}\n\n"
    if not content:
        return "No posts or comments found to build a persona."
    prompt = (
        "Based on the following Reddit posts and comments, create a user persona with details like interests, behavior, profession, etc. Also cite specific posts or comments where applicable:\n\n"
        + content
    )
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        persona = response['choices'][0]['message']['content']
        return persona
    except Exception as e:
        return f"Error generating persona: {e}"

def save_persona_to_file(username, persona):
    filename = f"{username}_persona.txt"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(persona)
    print(f"Persona saved to {filename}")

def extract_username(url):
    if '/user/' in url:
        return url.split('/user/')[1].split('/')[0]
    elif '/u/' in url:
        return url.split('/u/')[1].split('/')[0]
    else:
        return None

def main():
    deps_ok, praw, openai = check_dependencies()
    if not praw:
        print("Cannot proceed: 'praw' is required for Reddit access.")
        return
    reddit = praw.Reddit(
        client_id=REDDIT_CLIENT_ID,
        client_secret=REDDIT_CLIENT_SECRET,
        user_agent=REDDIT_USER_AGENT
    )
    if openai:
        openai.api_key = OPENAI_API_KEY
    else:
        print("Warning: 'openai' is not available. Persona generation will be skipped.")
    reddit_profile_url = input("Enter Reddit profile URL: ")
    username = extract_username(reddit_profile_url)
    if not username:
        print("Invalid Reddit profile URL.")
        return
    print(f"Fetching data for Reddit user: {username}")
    posts, comments = fetch_user_data(username, reddit)
    if openai:
        persona = build_persona(posts, comments, openai)
        save_persona_to_file(username, persona)
    else:
        print("Persona generation skipped due to missing 'openai' module.")

if __name__ == "__main__":
    main()

# --- Unit Tests ---
import unittest

class TestExtractUsername(unittest.TestCase):
    def test_user_url(self):
        self.assertEqual(extract_username('https://www.reddit.com/user/testuser/'), 'testuser')
        self.assertEqual(extract_username('https://reddit.com/user/testuser'), 'testuser')
    def test_u_url(self):
        self.assertEqual(extract_username('https://www.reddit.com/u/testuser/'), 'testuser')
        self.assertEqual(extract_username('https://reddit.com/u/testuser'), 'testuser')
    def test_no_user(self):
        self.assertIsNone(extract_username('https://www.reddit.com/r/python/'))
    def test_edge_cases(self):
        self.assertEqual(extract_username('https://reddit.com/user/testuser/comments'), 'testuser')
        self.assertEqual(extract_username('https://reddit.com/u/testuser/overview'), 'testuser')
        self.assertIsNone(extract_username('https://reddit.com/'))

# To run tests: python -m unittest reddit.py

# --- Enhancement Suggestion ---
# Consider replacing print statements with the 'logging' module for better control over output and log levels. 